# Nova TV Android — Enhanced starter

This revision improves the UI for phone and Android TV layouts and adds:
- Light/white theme by default, with a dark-mode switch.
- Animated soft orb/gradient decoration and redesigned home/category cards.
- Compact horizontal navigation on phones and a sidebar on wide screens.
- M3U URL loading or pasting M3U text directly.
- Group filters, search, favourites, and a Media3 playback dialog.
- Settings for playlist, theme, cache cleanup, and usage notes.

## Build
Open `NovaTV-Android-Studio` in Android Studio, allow Gradle sync, then run the `app` configuration.
The GitHub Actions workflow can also build a debug APK.

## Important content limitation
No TV channels, movies, series, sports streams, logos, or film database are bundled. Add an M3U playlist that you own or are authorized to use. The Live TV list is populated from that playlist. Movies/Series/Sports/Documentaries can only show entries if the playlist uses matching `group-title` values. This is a starter implementation, not a complete Netflix-style licensed catalogue service.

## Notes
- Country flag emojis are best-effort visual hints derived from playlist metadata/group names; they are not guaranteed accurate flags for every channel.
- Playlist URLs can expire or require authentication; some stream formats may not be supported by the device.
- Test on both a phone and Android TV device/emulator before release.

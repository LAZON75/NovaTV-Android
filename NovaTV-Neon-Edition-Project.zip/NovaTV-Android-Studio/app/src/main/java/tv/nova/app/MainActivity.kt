package tv.nova.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL

private val White = Color(0xFFF7F8FC)
private val Ink = Color(0xFF172033)
private val PanelLight = Color(0xFFFFFFFF)
private val MutedLight = Color(0xFF68748A)
private val Violet = Color(0xFF075BFF)
private val Cyan = Color(0xFF00C8FF)
private val DarkBg = Color(0xFF030A1C)
private val DarkPanel = Color(0xFF071936)
private val DarkMuted = Color(0xFFAAB4C8)

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        val prefs = getSharedPreferences("nova_settings", Context.MODE_PRIVATE)
        setContent {
            var darkMode by remember { mutableStateOf(prefs.getBoolean("dark_mode", true)) }
            val bg = if (darkMode) DarkBg else White
            val panel = if (darkMode) DarkPanel else PanelLight
            val ink = if (darkMode) Color.White else Ink
            val muted = if (darkMode) DarkMuted else MutedLight
            MaterialTheme(colorScheme = if (darkMode) darkColorScheme(
                primary = Violet, secondary = Cyan, background = bg, surface = panel,
                onBackground = ink, onSurface = ink
            ) else lightColorScheme(
                primary = Violet, secondary = Cyan, background = bg, surface = panel,
                onBackground = ink, onSurface = ink
            )) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                NovaHome(
                    darkMode = darkMode,
                    onDarkMode = {
                        darkMode = it
                        prefs.edit().putBoolean("dark_mode", it).apply()
                    },
                    backgroundColor = bg,
                    panelColor = panel,
                    textColor = ink,
                    mutedColor = muted,
                    savedPlaylist = prefs.getString("playlist_url", "") ?: "",
                    onSavePlaylist = { prefs.edit().putString("playlist_url", it).apply() },
                    onLoadPlaylist = { url, pasted, done -> loadPlaylist(url, pasted, done) },
                    onPlay = { channel -> playStream(channel) },
                    videoPlayer = player,
                    onStop = { player?.stop() },
                    onClearCache = { cacheDir.listFiles()?.forEach { it.deleteRecursively() } }
                )
                }
            }
        }
    }

    private fun playStream(channel: Channel) {
        val url = channel.url
        if (url.isBlank()) return
        player?.setMediaItem(MediaItem.fromUri(url))
        player?.prepare()
        player?.playWhenReady = true
    }

    private fun loadPlaylist(url: String, pasted: String, done: (List<Channel>, String?) -> Unit) {
        lifecycleScope.launch {
            try {
                val result = if (pasted.isNotBlank()) pasted else withContext(Dispatchers.IO) {
                    require(url.startsWith("https://") || url.startsWith("http://")) {
                        "أدخل رابط HTTP أو HTTPS صحيحًا، أو الصق محتوى M3U."
                    }
                    URL(url).openConnection().apply {
                        connectTimeout = 12000
                        readTimeout = 20000
                    }.getInputStream().bufferedReader().use { it.readText() }
                }
                val parsed = parseM3u(result)
                if (parsed.isEmpty()) done(emptyList(), "لم نجد قنوات. تأكد أن القائمة بصيغة M3U وتحتوي على روابط صالحة.")
                else done(parsed, null)
            } catch (e: Exception) {
                done(emptyList(), "تعذر تحميل القائمة: ${e.message ?: "تحقق من الرابط والإنترنت"}")
            }
        }
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}

data class Channel(
    val name: String,
    val url: String,
    val group: String = "Live TV",
    val logo: String = "",
    val country: String = ""
)

private fun parseM3u(text: String): List<Channel> {
    val result = mutableListOf<Channel>()
    var name = "Channel"
    var group = "Live TV"
    var logo = ""
    var country = ""
    for (raw in text.removePrefix("\uFEFF").lines()) {
        val line = raw.trim()
        if (line.startsWith("#EXTINF", true)) {
            name = line.substringAfter(",", "Channel").trim().ifBlank { "Channel" }
            group = Regex("""group-title="([^"]*)"""", RegexOption.IGNORE_CASE)
                .find(line)?.groupValues?.get(1)?.ifBlank { "Live TV" } ?: "Live TV"
            logo = Regex("""tvg-logo="([^"]*)"""", RegexOption.IGNORE_CASE)
                .find(line)?.groupValues?.get(1) ?: ""
            country = Regex("""tvg-country="([^"]*)"""", RegexOption.IGNORE_CASE)
                .find(line)?.groupValues?.get(1) ?: ""
        } else if (line.startsWith("http://") || line.startsWith("https://")) {
            result += Channel(name, line, group, logo, country)
            name = "Channel"
            group = "Live TV"
            logo = ""
            country = ""
        }
    }
    return result
}

private val navItems = listOf("Home", "Live TV", "Movies", "Series", "Sports", "Documentaries", "Favorites", "Settings")
private fun navIcon(section: String) = when (section) {
    "Home" -> Icons.Default.Home
    "Live TV" -> Icons.Default.Tv
    "Movies" -> Icons.Default.Movie
    "Series" -> Icons.Default.VideoLibrary
    "Sports" -> Icons.Default.SportsSoccer
    "Documentaries" -> Icons.Default.Public
    "Favorites" -> Icons.Default.Favorite
    else -> Icons.Default.Settings
}
private fun normalizedCountry(value: String): String {
    val v = value.trim().lowercase()
    return when {
        v.contains("morocco") || v.contains("maroc") || v.contains("المغرب") -> "Maroc"
        v.contains("alger") || v.contains("الجزائر") -> "Algérie"
        v.contains("tun") || v.contains("تونس") -> "Tunisie"
        v.contains("egypt") || v.contains("égypte") || v.contains("مصر") -> "Égypte"
        v.contains("libya") || v.contains("libye") || v.contains("ليبيا") -> "Libye"
        v.contains("sudan") || v.contains("السودان") -> "Soudan"
        v.contains("mauritania") || v.contains("mauritanie") || v.contains("موريتانيا") -> "Mauritanie"
        v.contains("saudi") || v.contains("arabie saoudite") || v.contains("السعودية") -> "Arabie Saoudite"
        v.contains("emirat") || v.contains("uae") || v.contains("الإمارات") -> "Émirats"
        v.contains("qatar") || v.contains("قطر") -> "Qatar"
        v.contains("kuwait") || v.contains("koweït") || v.contains("الكويت") -> "Koweït"
        v.contains("france") || v == "fr" || v.contains("français") || v.contains("فرنسا") -> "France"
        v.contains("united states") || v == "us" || v == "usa" || v.contains("america") || v.contains("أمريكا") -> "États-Unis"
        v.contains("canada") || v.contains("كندا") -> "Canada"
        v.contains("spain") || v.contains("espagne") || v.contains("español") || v.contains("إسبانيا") -> "Espagne"
        v.contains("germany") || v.contains("allemagne") || v.contains("deutsch") || v.contains("ألمانيا") -> "Allemagne"
        v.contains("ital") || v.contains("إيطاليا") -> "Italie"
        v.contains("portug") || v.contains("البرتغال") -> "Portugal"
        v.contains("turk") || v.contains("تركيا") -> "Turquie"
        v.contains("uk") || v.contains("brit") || v.contains("england") || v.contains("royaume-uni") -> "Royaume-Uni"
        v.contains("arab") || v.contains("arabe") || v.contains("عربي") -> "Toutes arabes"
        else -> value.trim().ifBlank { "Autres" }
    }
}
private fun countryFlag(value: String): String = when (normalizedCountry(value)) {
    "Maroc" -> "🇲🇦"; "Algérie" -> "🇩🇿"; "Tunisie" -> "🇹🇳"; "Égypte" -> "🇪🇬"
    "Libye" -> "🇱🇾"; "Soudan" -> "🇸🇩"; "Mauritanie" -> "🇲🇷"; "Arabie Saoudite" -> "🇸🇦"
    "Émirats" -> "🇦🇪"; "Qatar" -> "🇶🇦"; "Koweït" -> "🇰🇼"; "France" -> "🇫🇷"
    "États-Unis" -> "🇺🇸"; "Canada" -> "🇨🇦"; "Espagne" -> "🇪🇸"; "Allemagne" -> "🇩🇪"
    "Italie" -> "🇮🇹"; "Portugal" -> "🇵🇹"; "Turquie" -> "🇹🇷"; "Royaume-Uni" -> "🇬🇧"
    "Toutes arabes" -> "🌍"; else -> "📺"
}

@Composable
private fun NovaHome(
    darkMode: Boolean,
    onDarkMode: (Boolean) -> Unit,
    backgroundColor: Color,
    panelColor: Color,
    textColor: Color,
    mutedColor: Color,
    savedPlaylist: String,
    onSavePlaylist: (String) -> Unit,
    onLoadPlaylist: (String, String, (List<Channel>, String?) -> Unit) -> Unit,
    onPlay: (Channel) -> Unit,
    videoPlayer: ExoPlayer?,
    onStop: () -> Unit,
    onClearCache: () -> Unit
) {
    var selected by remember { mutableStateOf("Home") }
    var query by remember { mutableStateOf("") }
    var playlistUrl by remember { mutableStateOf(savedPlaylist) }
    var pastedM3u by remember { mutableStateOf("") }
    var channels by remember { mutableStateOf<List<Channel>>(emptyList()) }
    var favorites by remember { mutableStateOf<Set<String>>(emptySet()) }
    var message by remember { mutableStateOf("أضف قائمة M3U تملك حق استخدامها لعرض القنوات.") }
    var busy by remember { mutableStateOf(false) }
    var activeGroup by remember { mutableStateOf("All") }
    var liveTab by remember { mutableStateOf("Pays") }
    var activeCountry by remember { mutableStateOf("Toutes les chaînes") }
    var recentChannels by remember { mutableStateOf<List<String>>(emptyList()) }
    var playing by remember { mutableStateOf<Channel?>(null) }
    var showPaste by remember { mutableStateOf(false) }
    var language by remember { mutableStateOf("العربية") }
    var cacheMessage by remember { mutableStateOf("") }
    val config = LocalConfiguration.current
    val wide = config.screenWidthDp >= 900
    val compact = config.screenWidthDp < 600
    val groups = listOf("All") + channels.map { it.group }.distinct().filter { it.isNotBlank() }.sorted()
    val countries = listOf("Toutes les chaînes") + channels.map { normalizedCountry(it.country.ifBlank { it.group }) }.distinct().sorted()
    val visibleChannels = channels.filter { channel ->
        val queryMatches = channel.name.contains(query, true) || channel.group.contains(query, true) || channel.country.contains(query, true)
        val groupMatches = activeGroup == "All" || channel.group == activeGroup
        val countryMatches = selected != "Live TV" || liveTab != "Pays" || activeCountry == "Toutes les chaînes" || normalizedCountry(channel.country.ifBlank { channel.group }) == activeCountry
        val tabMatches = selected != "Live TV" || when (liveTab) { "Favoris" -> favorites.contains(channel.url); "Récents" -> recentChannels.contains(channel.url); else -> true }
        val sectionMatches = when (selected) {
            "Movies" -> channel.group.contains("movie", true) || channel.group.contains("film", true) || channel.group.contains("فيلم")
            "Series" -> channel.group.contains("series", true) || channel.group.contains("show", true) || channel.group.contains("مسلسل")
            "Sports" -> channel.group.contains("sport", true) || channel.group.contains("رياض")
            "Documentaries" -> channel.group.contains("document", true) || channel.group.contains("وثائقي")
            "Favorites" -> favorites.contains(channel.url)
            else -> true
        }
        queryMatches && groupMatches && countryMatches && tabMatches && sectionMatches
    }.sortedWith(compareBy<Channel> { normalizedCountry(it.country.ifBlank { it.group }) }.thenBy { it.name.lowercase() })

    Row(Modifier.fillMaxSize().background(backgroundColor)) {
        if (wide) {
            Column(
                Modifier.width(220.dp).fillMaxHeight().padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                BrandHeader(textColor, mutedColor)
                Spacer(Modifier.height(12.dp))
                navItems.forEach { item -> NavButton(item, selected == item, panelColor, textColor, mutedColor) { selected = item } }
                Spacer(Modifier.weight(1f))
                Text("NOVA TV • 2.0", color = mutedColor, fontSize = 11.sp, modifier = Modifier.padding(10.dp))
            }
        }
        Column(Modifier.weight(1f).fillMaxHeight()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = if (compact) 14.dp else 24.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!wide) {
                    BrandMark()
                    Spacer(Modifier.width(10.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text(when (selected) {
                        "Home" -> "Nova TV"
                        "Settings" -> "الإعدادات"
                        "Live TV" -> "البث المباشر"
                        "Movies" -> "الأفلام"
                        "Series" -> "المسلسلات"
                        "Sports" -> "الرياضة"
                        "Documentaries" -> "الوثائقيات"
                        "Favorites" -> "المفضلة"
                        else -> selected
                    }, color = textColor, fontSize = if (compact) 21.sp else 27.sp, fontWeight = FontWeight.ExtraBold)
                    if (!compact) Text("ترفيهك في مكان واحد", color = mutedColor, fontSize = 12.sp)
                }
                TextButton(onClick = { language = when (language) { "العربية" -> "Français"; "Français" -> "English"; else -> "العربية" } }) {
                    Icon(Icons.Default.Language, null)
                    if (!compact) { Spacer(Modifier.width(5.dp)); Text(language) }
                }
            }
            if (!wide) {
                LazyRow(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(navItems) { item ->
                        FilterChip(
                            selected = selected == item,
                            onClick = { selected = item },
                            label = { Text(item) },
                            leadingIcon = { Icon(navIcon(item), null, modifier = Modifier.size(17.dp)) }
                        )
                    }
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                AnimatedOrbs()
                if (selected == "Settings") {
                    SettingsScreen(
                        darkMode, onDarkMode, panelColor, textColor, mutedColor,
                        playlistUrl, { playlistUrl = it; onSavePlaylist(it) },
                        pastedM3u, { pastedM3u = it }, showPaste, { showPaste = it },
                        busy, message,
                        onLoad = {
                            busy = true
                            message = "جارٍ تحميل قائمة القنوات..."
                            onLoadPlaylist(playlistUrl, pastedM3u) { loaded, error ->
                                channels = loaded
                                activeGroup = "All"
                                message = error ?: "تم تحميل ${loaded.size} قناة بنجاح."
                                busy = false
                            }
                        },
                        onClearCache = {
                            onClearCache()
                            cacheMessage = "تم طلب تنظيف ملفات التخزين المؤقت."
                        },
                        cacheMessage = cacheMessage
                    )
                } else {
                    Column(Modifier.fillMaxSize().padding(horizontal = if (compact) 14.dp else 24.dp)) {
                        if (selected == "Home") {
                            HeroCard(panelColor, textColor, mutedColor, onBrowse = { selected = it })
                            Spacer(Modifier.height(18.dp))
                            Text("استكشف مكتبتك", color = textColor, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(10.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                items(listOf("Live TV", "Movies", "Series", "Sports", "Documentaries")) { section ->
                                    CategoryPoster(section, panelColor, textColor, mutedColor) { selected = section }
                                }
                            }
                            Spacer(Modifier.height(20.dp))
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(when (selected) {
                                "Live TV" -> "دليل القنوات"
                                "Movies" -> "مكتبة الأفلام"
                                "Series" -> "المسلسلات"
                                "Sports" -> "الرياضة"
                                "Documentaries" -> "الوثائقيات"
                                "Favorites" -> "المفضلة"
                                else -> "قنواتك ومحتواك"
                            }, color = textColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.weight(1f))
                            Text("${visibleChannels.size}", color = mutedColor, fontSize = 13.sp)
                        }
                        if (selected == "Live TV") {
                            Spacer(Modifier.height(8.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(listOf("Pays", "Catégories", "Favoris", "Récents")) { tab ->
                                    FilterChip(selected = liveTab == tab, onClick = { liveTab = tab }, label = { Text(tab) })
                                }
                            }
                            if (liveTab == "Pays") {
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                    OutlinedButton(onClick = { val i = countries.indexOf(activeCountry).coerceAtLeast(0); activeCountry = countries[(i - 1 + countries.size) % countries.size] }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(vertical = 7.dp)) { Text("▲") }
                                    OutlinedButton(onClick = { val i = countries.indexOf(activeCountry).coerceAtLeast(0); activeCountry = countries[(i + 1) % countries.size] }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(vertical = 7.dp)) { Text("▼") }
                                }
                                Spacer(Modifier.height(6.dp))
                                LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = if (compact) 170.dp else 210.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    items(countries) { country ->
                                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(if (activeCountry == country) Violet.copy(alpha = .15f) else panelColor.copy(alpha = .68f)).clickable { activeCountry = country; activeGroup = "All" }.focusable().padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Text(if (country == "Toutes les chaînes") "🌍" else countryFlag(country), fontSize = 19.sp)
                                            Spacer(Modifier.width(10.dp))
                                            Text(country, color = if (activeCountry == country) Violet else textColor, fontWeight = if (activeCountry == country) FontWeight.Bold else FontWeight.Medium)
                                            Spacer(Modifier.weight(1f))
                                            Text("${if (country == "Toutes les chaînes") channels.size else channels.count { normalizedCountry(it.country.ifBlank { it.group }) == country }}", color = mutedColor, fontSize = 12.sp)
                                        }
                                    }
                                }
                            } else if (liveTab == "Catégories") {
                                Spacer(Modifier.height(8.dp))
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(groups) { group -> FilterChip(selected = activeGroup == group, onClick = { activeGroup = group }, label = { Text(if (group == "All") "الكل" else group) }) }
                                }
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                                .background(panelColor).padding(horizontal = 12.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Search, null, tint = mutedColor)
                            Spacer(Modifier.width(8.dp))
                            BasicTextField(
                                value = query, onValueChange = { query = it },
                                modifier = Modifier.weight(1f).padding(vertical = 13.dp),
                                singleLine = true,
                                textStyle = androidx.compose.ui.text.TextStyle(color = textColor, fontSize = 14.sp, textDirection = TextDirection.ContentOrRtl),
                                decorationBox = { inner ->
                                    Box { if (query.isEmpty()) Text("ابحث عن قناة أو مجموعة...", color = mutedColor); inner() }
                                }
                            )
                            if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Default.Close, null, tint = mutedColor) }
                        }
                        Spacer(Modifier.height(12.dp))
                        if (visibleChannels.isEmpty()) {
                            EmptyState(
                                selected, textColor, mutedColor, panelColor,
                                onSettings = { selected = "Settings" }
                            )
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(9.dp),
                                contentPadding = PaddingValues(bottom = 24.dp)
                            ) {
                                items(visibleChannels) { channel ->
                                    ChannelRow(
                                        channel, panelColor, textColor, mutedColor,
                                        favorites.contains(channel.url),
                                        onFavorite = { favorites = if (favorites.contains(channel.url)) favorites - channel.url else favorites + channel.url },
                                        onPlay = { playing = channel; recentChannels = (listOf(channel.url) + recentChannels.filterNot { it == channel.url }).take(50); onPlay(channel) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (playing != null) {
        AlertDialog(
            onDismissRequest = { onStop(); playing = null },
            containerColor = panelColor,
            title = { Text(playing?.name ?: "Player", color = textColor) },
            text = {
                Column {
                    AndroidView(
                        modifier = Modifier.fillMaxWidth().height(if (compact) 190.dp else 300.dp),
                        factory = { context ->
                            PlayerView(context).apply {
                                useController = true
                                player = videoPlayer
                            }
                        },
                        update = { view -> view.player = videoPlayer }
                    )
                    Text("إذا لم يبدأ البث، فقد يكون الرابط منتهيًا أو يتطلب مصادقة أو صيغة غير مدعومة.", color = mutedColor, fontSize = 12.sp)
                }
            },
            confirmButton = { TextButton(onClick = { onStop(); playing = null }) { Text("إغلاق") } }
        )
    }
}

@Composable
private fun BrandMark() {
    Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Violet, Cyan))), contentAlignment = Alignment.Center) {
        Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(29.dp))
    }
}
@Composable
private fun BrandHeader(textColor: Color, muted: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        BrandMark()
        Column {
            Text("NOVA TV", color = textColor, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp)
            Text("ENTERTAINMENT", color = muted, fontSize = 9.sp, letterSpacing = 1.3.sp)
        }
    }
}
@Composable
private fun NavButton(item: String, active: Boolean, panel: Color, text: Color, muted: Color, click: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp))
            .background(if (active) Violet.copy(alpha = .13f) else Color.Transparent)
            .clickable(onClick = click).focusable().padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(navIcon(item), null, tint = if (active) Violet else muted)
        Text(item, color = if (active) Violet else text, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
    }
}
@Composable
private fun AnimatedOrbs() {
    val transition = rememberInfiniteTransition(label = "orbs")
    val s1 by transition.animateFloat(1f, 1.12f, infiniteRepeatable(tween(2600), RepeatMode.Reverse), label = "orb1")
    val s2 by transition.animateFloat(1.1f, .92f, infiniteRepeatable(tween(3400), RepeatMode.Reverse), label = "orb2")
    Box(Modifier.fillMaxSize()) {
        Box(Modifier.align(Alignment.TopEnd).padding(top = 24.dp, end = 30.dp).size(110.dp).scale(s1).clip(CircleShape).background(Brush.radialGradient(listOf(Cyan.copy(alpha = .10f), Color.Transparent))))
        Box(Modifier.align(Alignment.BottomEnd).padding(end = 70.dp, bottom = 60.dp).size(150.dp).scale(s2).clip(CircleShape).background(Brush.radialGradient(listOf(Violet.copy(alpha = .09f), Color.Transparent))))
    }
}
@Composable
private fun HeroCard(panel: Color, text: Color, muted: Color, onBrowse: (String) -> Unit) {
    val transition = rememberInfiniteTransition(label = "hero")
    val scale by transition.animateFloat(1f, 1.025f, infiniteRepeatable(tween(2200), RepeatMode.Reverse), label = "heroScale")
    Box(
        Modifier.fillMaxWidth().height(176.dp).scale(scale).clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(Color(0xFFFDFEFF), Color(0xFFE9E6FF), Color(0xFFDFF8FA))))
            .padding(20.dp)
    ) {
        Column(Modifier.align(Alignment.CenterStart).fillMaxWidth(.78f)) {
            Text("NOVA • ENTERTAINMENT", color = Violet, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Spacer(Modifier.height(7.dp))
            Text("عالمك الترفيهي،\nبتصميم جديد", color = Color(0xFF172033), fontSize = 23.sp, lineHeight = 28.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(6.dp))
            Text("قنوات • أفلام • مسلسلات • رياضة", color = Color(0xFF5E6880), fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Button(onClick = { onBrowse("Live TV") }, contentPadding = PaddingValues(horizontal = 14.dp, vertical = 5.dp)) {
                Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(4.dp)); Text("شاهد الآن")
            }
        }
        Box(Modifier.align(Alignment.CenterEnd).padding(end = 12.dp).size(72.dp).scale(scale).clip(CircleShape).background(Brush.linearGradient(listOf(Color.White, Color(0xFFBDECF3)))), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.PlayArrow, null, tint = Violet, modifier = Modifier.size(44.dp))
        }
    }
}
@Composable
private fun CategoryPoster(section: String, panel: Color, text: Color, muted: Color, click: () -> Unit) {
    val tint = when (section) {
        "Movies" -> Color(0xFFE9DDFB)
        "Series" -> Color(0xFFDDF5F7)
        "Sports" -> Color(0xFFFFE9D7)
        "Documentaries" -> Color(0xFFE2E9FF)
        else -> Color(0xFFE4E5FF)
    }
    Column(
        Modifier.width(128.dp).clip(RoundedCornerShape(18.dp)).background(panel)
            .clickable(onClick = click).focusable().padding(10.dp)
    ) {
        Box(Modifier.fillMaxWidth().height(80.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(tint, Color.White))), contentAlignment = Alignment.Center) {
            Icon(navIcon(section), null, tint = Violet, modifier = Modifier.size(36.dp))
        }
        Spacer(Modifier.height(9.dp))
        Text(section, color = text, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("افتح القسم", color = muted, fontSize = 11.sp)
    }
}
@Composable
private fun ChannelRow(
    channel: Channel, panel: Color, text: Color, muted: Color, favorite: Boolean,
    onFavorite: () -> Unit, onPlay: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(panel)
            .clickable(onClick = onPlay).focusable().padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(45.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(Color(0xFFE7E4FF), Color(0xFFDDF7F8)))), contentAlignment = Alignment.Center) {
            Text(countryFlag(channel.country.ifBlank { channel.group }), fontSize = 22.sp)
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(channel.name, color = text, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(channel.group, color = muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton(onClick = onFavorite) {
            Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (favorite) Color(0xFFE35D7A) else muted)
        }
        Icon(Icons.Default.PlayCircle, null, tint = Violet, modifier = Modifier.size(27.dp))
    }
}
@Composable
private fun EmptyState(section: String, text: Color, muted: Color, panel: Color, onSettings: () -> Unit) {
    Box(Modifier.fillMaxWidth().padding(vertical = 26.dp), contentAlignment = Alignment.Center) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(panel).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(if (section == "Favorites") Icons.Default.FavoriteBorder else Icons.Default.TvOff, null, tint = Violet, modifier = Modifier.size(42.dp))
            Spacer(Modifier.height(10.dp))
            Text(if (section == "Favorites") "لا توجد عناصر مفضلة بعد" else "مكتبتك جاهزة لاستقبال المحتوى", color = text, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text("أضف قائمة M3U قانونية من الإعدادات لعرض القنوات المتاحة.", color = muted, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            Button(onClick = onSettings) { Icon(Icons.Default.Settings, null); Spacer(Modifier.width(6.dp)); Text("فتح الإعدادات") }
        }
    }
}
@Composable
private fun SettingsScreen(
    darkMode: Boolean, onDarkMode: (Boolean) -> Unit,
    panel: Color, text: Color, muted: Color,
    playlistUrl: String, onPlaylistUrl: (String) -> Unit,
    pastedM3u: String, onPastedM3u: (String) -> Unit,
    showPaste: Boolean, onShowPaste: (Boolean) -> Unit,
    busy: Boolean, message: String,
    onLoad: () -> Unit, onClearCache: () -> Unit, cacheMessage: String
) {
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 28.dp)
    ) {
        item {
            SettingsCard(panel, text, muted, "المظهر", Icons.Default.Palette) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("الوضع الداكن", color = text, fontWeight = FontWeight.SemiBold)
                        Text("التبديل بين الواجهة البيضاء والداكنة", color = muted, fontSize = 12.sp)
                    }
                    Switch(checked = darkMode, onCheckedChange = onDarkMode)
                }
            }
        }
        item {
            SettingsCard(panel, text, muted, "مصدر القنوات", Icons.Default.PlaylistPlay) {
                Text("أدخل رابط قائمة M3U تملك حق استخدامها. يمكن أيضًا لصق محتوى القائمة مباشرة.", color = muted, fontSize = 12.sp)
                Spacer(Modifier.height(9.dp))
                InputBox(playlistUrl, onPlaylistUrl, "https://example.com/playlist.m3u", text, muted, false)
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { onShowPaste(!showPaste) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.ContentPaste, null); Spacer(Modifier.width(6.dp))
                    Text(if (showPaste) "إخفاء حقل لصق القائمة" else "لصق قائمة M3U بدل الرابط")
                }
                if (showPaste) {
                    Spacer(Modifier.height(8.dp))
                    InputBox(pastedM3u, onPastedM3u, "#EXTM3U\n#EXTINF:-1,اسم القناة\nhttps://...", text, muted, true)
                }
                Spacer(Modifier.height(10.dp))
                Button(onClick = onLoad, enabled = !busy && (playlistUrl.isNotBlank() || pastedM3u.isNotBlank()), modifier = Modifier.fillMaxWidth()) {
                    if (busy) CircularProgressIndicator(Modifier.size(17.dp), strokeWidth = 2.dp)
                    else Icon(Icons.Default.CloudDownload, null)
                    Spacer(Modifier.width(7.dp)); Text(if (busy) "جارٍ التحميل..." else "تحميل / تحديث القائمة")
                }
                Text(message, color = if (message.contains("تعذر") || message.contains("لم نجد")) Color(0xFFCE4A4A) else muted, fontSize = 12.sp)
            }
        }
        item {
            SettingsCard(panel, text, muted, "التخزين والصيانة", Icons.Default.CleaningServices) {
                Text("امسح الملفات المؤقتة عند حدوث مشكلة. لن يحذف ذلك قائمة القنوات من مزودك.", color = muted, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = onClearCache, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.DeleteSweep, null); Spacer(Modifier.width(6.dp)); Text("تنظيف التخزين المؤقت")
                }
                if (cacheMessage.isNotBlank()) Text(cacheMessage, color = muted, fontSize = 12.sp)
            }
        }
        item {
            SettingsCard(panel, text, muted, "التشغيل والخصوصية", Icons.Default.Security) {
                Text("• استخدم روابط بث تملكها أو لديك إذن بمشاهدتها.\n• قد لا تعمل بعض الروابط إذا انتهت صلاحيتها أو احتاجت تسجيل دخول.\n• التطبيق لا يتضمن قنوات أو أفلامًا جاهزة افتراضيًا.", color = muted, fontSize = 12.sp, lineHeight = 19.sp)
            }
        }
        item {
            SettingsCard(panel, text, muted, "حول Nova TV", Icons.Default.Info) {
                Text("Nova TV • الإصدار 2.0\nواجهة محسّنة للهاتف وAndroid TV، دعم قوائم M3U والمفضلة والوضع الداكن.", color = muted, fontSize = 12.sp, lineHeight = 19.sp)
            }
        }
    }
}
@Composable
private fun SettingsCard(
    panel: Color, text: Color, muted: Color, title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = panel),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, muted.copy(alpha = .12f))
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = Violet)
                Spacer(Modifier.width(8.dp))
                Text(title, color = text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
            content()
        }
    }
}
@Composable
private fun InputBox(
    value: String, onValueChange: (String) -> Unit, hint: String,
    text: Color, muted: Color, multiline: Boolean
) {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
            .background(muted.copy(alpha = .08f)).padding(12.dp)
    ) {
        if (value.isEmpty()) Text(hint, color = muted, fontSize = 12.sp)
        BasicTextField(
            value = value, onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth().heightIn(min = if (multiline) 100.dp else 22.dp, max = if (multiline) 220.dp else 50.dp),
            singleLine = !multiline,
            textStyle = androidx.compose.ui.text.TextStyle(color = text, fontSize = 13.sp, lineHeight = 18.sp, textDirection = TextDirection.ContentOrRtl)
        )
    }
}

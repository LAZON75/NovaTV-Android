# Nova TV — Neon Edition

This is a refreshed copy of the existing Nova TV Android project, preserving its Kotlin/Jetpack Compose app structure, ExoPlayer playback, M3U URL/paste loading, favorites/recent channel state, country/category filtering, and settings screen.

## Visual refresh
- Dark navy appearance enabled by default for new installs.
- Electric blue and cyan accent colors inspired by the approved Nova TV concept.
- Existing animated orb backdrop and glass-like panels remain part of the UI.
- The user's saved dark/light preference is still respected after they change it in Settings.

## Build
Open `NovaTV-Android-Studio` in Android Studio, or use the repository's GitHub Actions workflow if you have configured it. This source archive has not been built or runtime-tested in this environment; verify the build before distributing an APK.

## Playlists
Only load M3U playlists you own or are authorized to use.

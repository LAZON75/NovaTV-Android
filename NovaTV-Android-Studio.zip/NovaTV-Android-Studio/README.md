# Nova TV — Android Studio starter

Nova TV is a fresh Kotlin + Jetpack Compose starter for Android phones and Android TV.

## Included
- Dark premium-style home screen and navigation
- Live TV, Movies, Series, Sports, Documentaries, and Settings sections
- M3U playlist URL loader and basic `#EXTINF` parser
- Media3 ExoPlayer stream playback
- Simple language toggle UI
- Leanback launcher category and focusable navigation basics

## Open in Android Studio
1. Extract this ZIP.
2. Open the `NovaTV-Android-Studio` folder in Android Studio.
3. Allow Gradle sync.
4. Run on an Android phone or Android TV emulator/device.

## Important
This is a source-code starter, not a compiled APK. It has not been built or device-tested in this environment. Build it in Android Studio and fix any SDK/Gradle issues shown there before release.

Playback requires a working, lawful M3U playlist and stream URLs supported by Media3. A playlist URL is not included. The current player starts playback when a channel is selected, but a dedicated in-app video surface and richer TV remote testing are still follow-up tasks. Movies/Series/Sports categories are UI scaffolding until the playlist supplies category metadata or a catalog source is integrated.

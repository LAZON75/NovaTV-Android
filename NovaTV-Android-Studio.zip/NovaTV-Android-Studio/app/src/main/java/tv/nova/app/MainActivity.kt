package tv.nova.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL

private val Ink = Color(0xFF080B16)
private val Panel = Color(0xFF11172A)
private val Violet = Color(0xFF8B5CF6)
private val Cyan = Color(0xFF22D3EE)
private val Muted = Color(0xFF9AA5C0)

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Violet, secondary = Cyan, background = Ink,
                surface = Panel, onBackground = Color.White, onSurface = Color.White
            )) {
                NovaHome(
                    onPlay = { stream -> playStream(stream) },
                    onLoadPlaylist = { url, done -> loadPlaylist(url, done) }
                )
            }
        }
    }

    private fun playStream(url: String) {
        if (url.isBlank()) return
        player?.setMediaItem(MediaItem.fromUri(url))
        player?.prepare()
        player?.playWhenReady = true
    }

    private fun loadPlaylist(url: String, done: (List<Channel>, String?) -> Unit) {
        lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    require(url.startsWith("https://") || url.startsWith("http://")) {
                        "دخل رابط HTTP أو HTTPS صحيح."
                    }
                    URL(url).openConnection().apply {
                        connectTimeout = 10000
                        readTimeout = 15000
                    }.getInputStream().bufferedReader().use { it.readText() }
                }
                val channels = parseM3u(result)
                if (channels.isEmpty()) done(emptyList(), "ما لقيناش قنوات فهاد الملف.")
                else done(channels, null)
            } catch (e: Exception) {
                done(emptyList(), "تعذر تحميل الملف: ${e.message ?: "خطأ غير معروف"}")
            }
        }
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}

data class Channel(val name: String, val url: String, val group: String = "Live TV")

private fun parseM3u(text: String): List<Channel> {
    val lines = text.lines().map { it.trim() }
    val result = mutableListOf<Channel>()
    var name = "Channel"
    var group = "Live TV"
    for (line in lines) {
        if (line.startsWith("#EXTINF", true)) {
            name = line.substringAfter(",", "Channel").trim().ifBlank { "Channel" }
            group = Regex("""group-title="([^"]*)"""").find(line)?.groupValues?.get(1) ?: "Live TV"
        } else if (line.startsWith("http://") || line.startsWith("https://")) {
            result += Channel(name, line, group)
            name = "Channel"
        }
    }
    return result
}

@Composable
private fun NovaHome(
    onPlay: (String) -> Unit,
    onLoadPlaylist: (String, (List<Channel>, String?) -> Unit) -> Unit
) {
    var selected by remember { mutableStateOf("Home") }
    var query by remember { mutableStateOf("") }
    var playlistUrl by remember { mutableStateOf("") }
    var channels by remember { mutableStateOf<List<Channel>>(emptyList()) }
    var message by remember { mutableStateOf("أضف رابط M3U مرخّص باش تبدا.") }
    var busy by remember { mutableStateOf(false) }
    var language by remember { mutableStateOf("العربية") }
    val sections = listOf("Home", "Live TV", "Movies", "Series", "Sports", "Documentaries", "Settings")
    val visibleChannels = channels.filter {
        it.name.contains(query, ignoreCase = true) ||
            it.group.contains(query, ignoreCase = true)
    }

    Row(
        Modifier.fillMaxSize().background(
            Brush.linearGradient(listOf(Ink, Color(0xFF10132B), Color(0xFF090D19)))
        )
    ) {
        Column(
            Modifier.width(190.dp).fillMaxHeight().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(
                    Brush.linearGradient(listOf(Violet, Cyan))
                ), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.PlayArrow, null, tint = Color.White)
                }
                Column {
                    Text("NOVA TV", fontWeight = FontWeight.Black, letterSpacing = 1.4.sp)
                    Text("ENTERTAINMENT", fontSize = 9.sp, color = Muted, letterSpacing = 1.5.sp)
                }
            }
            Spacer(Modifier.height(18.dp))
            sections.forEach { section ->
                val active = selected == section
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                        .background(if (active) Violet.copy(alpha = .22f) else Color.Transparent)
                        .clickable { selected = section }
                        .focusable()
                        .padding(horizontal = 12.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        when (section) {
                            "Home" -> Icons.Default.Home
                            "Live TV" -> Icons.Default.Tv
                            "Movies" -> Icons.Default.Movie
                            "Series" -> Icons.Default.VideoLibrary
                            "Sports" -> Icons.Default.SportsSoccer
                            "Documentaries" -> Icons.Default.Public
                            else -> Icons.Default.Settings
                        }, null, tint = if (active) Cyan else Muted
                    )
                    Text(section, color = if (active) Color.White else Muted, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal)
                }
            }
            Spacer(Modifier.weight(1f))
            Text("NOVA • 1.0", color = Muted, fontSize = 11.sp)
        }

        Column(Modifier.fillMaxSize().padding(start = 18.dp, end = 24.dp, top = 24.dp, bottom = 20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        when (selected) {
                            "Home" -> "Welcome to Nova TV"
                            "Settings" -> "Settings"
                            else -> selected
                        }, fontSize = 27.sp, fontWeight = FontWeight.Bold
                    )
                    Text("Your entertainment, beautifully organized.", color = Muted, fontSize = 13.sp)
                }
                TextButton(onClick = { language = if (language == "العربية") "Français" else if (language == "Français") "English" else "العربية" }) {
                    Icon(Icons.Default.Language, null)
                    Spacer(Modifier.width(6.dp))
                    Text(language)
                }
            }
            Spacer(Modifier.height(22.dp))

            if (selected == "Settings") {
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Playlist source", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("Paste an M3U playlist URL you are authorized to use.", color = Muted, fontSize = 13.sp)
                        BasicTextField(
                            value = playlistUrl,
                            onValueChange = { playlistUrl = it },
                            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF080D1C)).padding(14.dp),
                            singleLine = true,
                            textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp),
                            decorationBox = { inner ->
                                Box {
                                    if (playlistUrl.isEmpty()) Text("https://example.com/playlist.m3u", color = Muted)
                                    inner()
                                }
                            }
                        )
                        Button(
                            onClick = {
                                busy = true
                                message = "جاري تحميل القائمة..."
                                onLoadPlaylist(playlistUrl) { loaded, error ->
                                    channels = loaded
                                    message = error ?: "تحمّلات ${loaded.size} قناة بنجاح."
                                    busy = false
                                }
                            },
                            enabled = !busy && playlistUrl.isNotBlank()
                        ) {
                            if (busy) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                            else Icon(Icons.Default.CloudDownload, null)
                            Spacer(Modifier.width(8.dp))
                            Text(if (busy) "Loading..." else "Load playlist")
                        }
                        Text(message, color = if (message.startsWith("تعذر") || message.contains("ما لقيناش")) Color(0xFFFCA5A5) else Cyan, fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text("Note: the app provides a player shell; channel availability depends on your playlist and provider.", color = Muted, fontSize = 12.sp)
            } else {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel).padding(horizontal = 14.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Search, null, tint = Muted)
                    Spacer(Modifier.width(8.dp))
                    BasicTextField(
                        value = query, onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                        textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp),
                        decorationBox = { inner ->
                            Box {
                                if (query.isEmpty()) Text("Search channels...", color = Muted)
                                inner()
                            }
                        }
                    )
                }
                Spacer(Modifier.height(18.dp))
                if (selected == "Home") {
                    Box(
                        Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(22.dp))
                            .background(Brush.linearGradient(listOf(Color(0xFF39216F), Color(0xFF123C56), Panel)))
                            .padding(22.dp)
                    ) {
                        Column(Modifier.align(Alignment.CenterStart)) {
                            Text("STREAM WITHOUT LIMITS", color = Cyan, fontSize = 11.sp, letterSpacing = 2.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("A new way to watch.", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                            Text("Live TV • Movies • Series • Sports", color = Color(0xFFD5D9EA), fontSize = 13.sp)
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("Browse your library", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        listOf("Live TV", "Movies", "Series", "Sports").forEach { item ->
                            Box(
                                Modifier.weight(1f).height(76.dp).clip(RoundedCornerShape(16.dp))
                                    .background(Panel).clickable { selected = item }.focusable().padding(12.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Column {
                                    Icon(
                                        when (item) {
                                            "Live TV" -> Icons.Default.Tv
                                            "Movies" -> Icons.Default.Movie
                                            "Series" -> Icons.Default.VideoLibrary
                                            else -> Icons.Default.SportsSoccer
                                        }, null, tint = Cyan
                                    )
                                    Text(item, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (selected == "Home") "Available channels" else selected, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Text("${visibleChannels.size} items", color = Muted, fontSize = 12.sp)
                }
                Spacer(Modifier.height(8.dp))
                if (visibleChannels.isEmpty()) {
                    Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.TvOff, null, tint = Muted, modifier = Modifier.size(42.dp))
                            Spacer(Modifier.height(10.dp))
                            Text("No channels loaded yet", fontWeight = FontWeight.Bold)
                            Text("Open Settings and add your M3U playlist URL.", color = Muted, fontSize = 12.sp)
                        }
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(visibleChannels) { channel ->
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel)
                                    .clickable { onPlay(channel.url) }.focusable().padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF202744)), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.PlayCircle, null, tint = Cyan)
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(channel.name, fontWeight = FontWeight.SemiBold)
                                    Text(channel.group, color = Muted, fontSize = 11.sp)
                                }
                                Icon(Icons.Default.PlayArrow, null, tint = Violet)
                            }
                        }
                    }
                }
            }
        }
    }
}
